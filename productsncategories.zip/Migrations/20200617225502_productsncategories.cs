﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace productsncategories.Migrations
{
    public partial class productsncategories : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
